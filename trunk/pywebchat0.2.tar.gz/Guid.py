
import random

class Guid:

	def __innit__(self):
		
